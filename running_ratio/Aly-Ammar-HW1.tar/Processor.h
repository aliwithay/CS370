extern double get_running_ratio();
